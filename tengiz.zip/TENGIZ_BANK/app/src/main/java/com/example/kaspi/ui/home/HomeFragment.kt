package com.example.kaspi.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import androidx.fragment.app.Fragment
import com.example.kaspi.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val imageButton1 = binding.imageButton1
        val imageButton2 = binding.imageButton2
        val imageButton3 = binding.imageButton3
        val imageButton4 = binding.imageButton4
        val imageButton5 = binding.imageButton5
        val imageButton6 = binding.imageButton6
        val imageButton7 = binding.imageButton7
        val imageButton8 = binding.imageButton8

        imageButton1.setOnClickListener {
            animateImageButton(it)
        }

        imageButton2.setOnClickListener {
            animateImageButton(it)
        }

        imageButton3.setOnClickListener {
            animateImageButton(it)
        }

        imageButton4.setOnClickListener {
            animateImageButton(it)
        }

        imageButton5.setOnClickListener {
            animateImageButton(it)
        }

        imageButton6.setOnClickListener {
            animateImageButton(it)
        }

        imageButton7.setOnClickListener {
            animateImageButton(it)
        }

        imageButton8.setOnClickListener {
            animateImageButton(it)
        }

        return root
    }

    // Функция для анимации ImageButton
    private fun animateImageButton(view: View) {
        val scaleAnimation = ScaleAnimation(1f, 0.9f, 1f, 0.9f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
        scaleAnimation.duration = 100
        view.startAnimation(scaleAnimation)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}